package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int a=Integer.parseInt(request.getParameter("rating"));
    	int b;
    	switch(a) {
    	case 1 :
    		b=5;
    		request.setAttribute("E", b);
    		RequestDispatcher rd=request.getRequestDispatcher("ans.jsp");
    		rd.forward(request, response);

    		break;
    	case 2 :
    		b=4;
    		request.setAttribute("E", b);
    		RequestDispatcher r=request.getRequestDispatcher("ans.jsp");
    		r.forward(request, response);
    		break;
    	case 3 :
    		b=3;
    		request.setAttribute("E", b);
    		RequestDispatcher d=request.getRequestDispatcher("ans.jsp");
    		d.forward(request, response);
    		break;
    	case 4 :
    		b=2;
    		request.setAttribute("E", b);
    		RequestDispatcher f=request.getRequestDispatcher("ans.jsp");
    		f.forward(request, response);
    		break;
    	default :
    		b=1;
    		request.setAttribute("E", b);
    		RequestDispatcher o=request.getRequestDispatcher("ans.jsp");
    		o.forward(request, response);
    	}


    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String a=request.getParameter("admin");
		 //Conditional operator
		int flag=("admin".equalsIgnoreCase(a))?0:1; 
		//if-else Condition
	    if(flag==0){                                           
	    	RequestDispatcher rd=request.getRequestDispatcher("process.jsp");
			rd.forward(request, response);
	    }
	    else{
	    	RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
	    }
	    //without Conditional operator
		/*if("admin".equalsIgnoreCase(a)){
			RequestDispatcher rd=request.getRequestDispatcher("process.jsp");
			rd.forward(request, response);
		}
		else{
		RequestDispatcher rd=request.getRequestDispatcher("success.jsp");
		rd.forward(request, response);
		}*/
	}

}
