package usingscanner;

public abstract class Area {  //abstraction
	public double Area;
	  public double circle(double radius){
	    	Area=3.14*radius*radius;
	    	return Area;
	    }
	    public double rectangle(double lenght,double breadh){
	    	Area=lenght*breadh;
	    	return Area;
	    }
	    public abstract double square(double a);
	    public abstract double triangle(double b,double h);
}
