package usingscanner;

public class Area1 extends Area {

	@Override
	public double square(double a) {//inheritance
		Area=a*a;
    	return Area;
	}

	@Override
	public double triangle(double b, double h) {
		Area=0.5*b*h;
    	return Area;
	}

}
