package usingscanner;

import java.util.Scanner;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Nature N=new Nature();
		Area A=new Area1();
		Scanner sc=new Scanner(System.in);  
		System.out.println("Enter 1 to find Area of circle ");
		System.out.print(" Otherwise Enter -1:");
		int flag=sc.nextInt();
		if(flag==1){
			System.out.println("Enter radius:");
			double Radius=sc.nextDouble(); 
			N.setRadius(Radius);
			N.getRadius();
			System.out.println("Area of Circle:"+A.circle(N.getRadius()));
		}
		else if(flag==-1){
			System.out.println("Enter 1 to find Area of Rectangle ");
			System.out.print(" Otherwise Enter -1:");
			int flag1=sc.nextInt();
			if(flag1==1){
				System.out.println("Enter length and Breadth:");
				double length=sc.nextDouble(); 
				double Breadth=sc.nextDouble(); 
				N.setLength(length);
				N.setBreadth(Breadth);
				System.out.println("Area of Rectangle:"+A.rectangle(N.getLength(), N.getBreadth()));
			}
			else if(flag1==-1){
				System.out.println("Enter 1 to find Area of Square ");
				System.out.print(" Otherwise Enter -1:");
				int flag2=sc.nextInt();
				if(flag2==1){
					System.out.println("Enter Side:");
					double side=sc.nextDouble();
					N.setA(side);
					System.out.println("Area of Square:"+A.square(N.getA()));
				}
				else if(flag2==-1){
					System.out.println("Enter 1 to find Area of Triangle ");
					System.out.print(" Otherwise Enter -1:");
					int flag3=sc.nextInt();
					if(flag3==1){
						System.out.println("Enter width and Breadth:");
						double width=sc.nextDouble(); 
						double B=sc.nextDouble();
						N.setB(B);
						N.setH(width);
						System.out.println("Area of Triangle:"+A.triangle(N.getB(), N.getH()));
					}

					else if(flag3==-1){
						System.out.println("Exit");
					}
					else{
						System.out.println("Invalid Number");
					}
				}
				else{
					System.out.println("Invalid Number");
				}
			}
			else{
				System.out.println("Invalid Number");
			}
		}
		else{
			System.out.println("Invalid Number");
		}
	}
	
	
}
